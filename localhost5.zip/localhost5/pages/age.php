<div class="container calculator">
	<div class="row">
		<div class="col-sm-12">
			<?php $dateOfBirth = "17-10-1985";
$today = date("Y-m-d");
$diff = date_diff(date_create($dateOfBirth), date_create($today));
echo 'Age is '.$diff->format('%y'); ?>
		</div>
	</div>
</div>